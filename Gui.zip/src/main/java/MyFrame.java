import javax.swing.*;
import java.awt.*;

public class MyFrame extends JFrame{
  MyFrame(){
    this.setTitle("InventaX");
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setResizable(false);
    this.setSize(420, 420);
    this.setVisible(true);
    ImageIcon image = new ImageIcon("src/img/logo.jpg");
    this.setIconImage(image.getImage());
    this.getContentPane().setBackground(new Color(0xFFFFFF)); 
  
   
    JMenuBar menuBar = new JMenuBar();
    this.setJMenuBar(menuBar);
    menuBar.setBackground(new Color (34, 139, 34));

    JMenu nameofProgram = new JMenu("InvetaX");
    JMenu homeMenu = new JMenu("Home");
    JMenu inventarioMenu = new JMenu("Inventario");
    JMenu ventasMenu = new JMenu("Ventas");
    JMenu clientesMenu = new JMenu("Clientes");
    JMenu proveedoresMenu = new JMenu("Proveedores");
    JMenu usuariosMenu = new JMenu("Usuarios");
    JMenu reportesMenu = new JMenu("Reportes");

    menuBar.add(nameofProgram);
    menuBar.add(homeMenu);
    menuBar.add(inventarioMenu);
    menuBar.add(ventasMenu);
    menuBar.add(clientesMenu);
    menuBar.add(proveedoresMenu);
    menuBar.add(usuariosMenu);
    menuBar.add(reportesMenu);

    nameofProgram.setForeground(Color.BLACK);
   
    homeMenu.setFont(new Font ("Helvetica", Font.PLAIN, 16));
    homeMenu.setForeground(Color.WHITE);
    
    inventarioMenu.setFont(new Font ("Helvetica", Font.PLAIN, 16));
    inventarioMenu.setForeground(Color.WHITE);
    
    ventasMenu.setFont(new Font ("Helvetica", Font.PLAIN, 16));
    ventasMenu.setForeground(Color.WHITE);
    
    clientesMenu.setFont(new Font ("Helvetica", Font.PLAIN, 16));
    clientesMenu.setForeground(Color.WHITE);
    
    proveedoresMenu.setFont(new Font ("Helvetica", Font.PLAIN, 16));
    proveedoresMenu.setForeground(Color.WHITE);
    
    usuariosMenu.setFont(new Font ("Helvetica", Font.PLAIN, 16));
    usuariosMenu.setForeground(Color.WHITE);
    
    reportesMenu.setFont(new Font ("Helvetica", Font.PLAIN, 16));
    reportesMenu.setForeground(Color.WHITE);

    this.setVisible(true);
    
    
  } 
}